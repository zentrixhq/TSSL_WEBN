import { useState, useEffect } from 'react';
import Header from '../components/Header';
import SearchBar from '../components/SearchBar';
import BrandCard from '../components/BrandCard';
import Footer from '../components/Footer';
import { supabase, Product } from '../lib/supabase';

interface HomepageSection {
  id: string;
  category_id: string | null;
  title: string;
  display_order: number;
  max_products: number;
  show_trending: boolean;
  show_title: boolean;
  categories?: {
    slug: string;
  };
}

interface CategorySection {
  section: HomepageSection;
  products: (Product & { offers: number })[];
}

interface NoticeBarSettings {
  enabled: boolean;
  text: string;
  bgColor: string;
  textColor: string;
  link?: string;
  imageUrl?: string;
}

export default function HomePage() {
  const [activeCategory, setActiveCategory] = useState('All');
  const [categorySections, setCategorySections] = useState<CategorySection[]>([]);
  const [bannerUrl, setBannerUrl] = useState('https://i.postimg.cc/7Z4cHD57/banner3.jpg');
  const [mobileBannerUrl, setMobileBannerUrl] = useState('');
  const [noticeBar, setNoticeBar] = useState<NoticeBarSettings>({
    enabled: false,
    text: '',
    bgColor: '#DC2626',
    textColor: '#FFFFFF',
  });
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetchData();
  }, []);

  const fetchData = async () => {
    try {
      const { data: settingsData, error: settingsError } = await supabase
        .from('homepage_settings')
        .select('*')
        .limit(1)
        .maybeSingle();

      if (!settingsError && settingsData) {
        if (settingsData.banner_image_url) {
          setBannerUrl(settingsData.banner_image_url);
        }
        if (settingsData.mobile_banner_image_url) {
          setMobileBannerUrl(settingsData.mobile_banner_image_url);
        }

        setNoticeBar({
          enabled: settingsData.notice_bar_enabled || false,
          text: settingsData.notice_bar_text || '',
          bgColor: settingsData.notice_bar_bg_color || '#DC2626',
          textColor: settingsData.notice_bar_text_color || '#FFFFFF',
          link: settingsData.notice_bar_link,
          imageUrl: settingsData.notice_bar_image_url,
        });
      }

      const { data: sectionsData, error: sectionsError } = await supabase
        .from('homepage_sections')
        .select(`
          *,
          categories (
            slug
          )
        `)
        .eq('is_active', true)
        .order('display_order');

      if (sectionsError) throw sectionsError;

      const { data: offersData, error: offersError } = await supabase
        .from('product_offers')
        .select('product_id')
        .eq('is_available', true);

      if (offersError) throw offersError;

      const offerCounts = offersData.reduce((acc, offer) => {
        acc[offer.product_id] = (acc[offer.product_id] || 0) + 1;
        return acc;
      }, {} as Record<string, number>);

      const sections: CategorySection[] = [];

      for (const section of sectionsData || []) {
        let productsData;

        if (section.show_trending) {
          const { data, error } = await supabase
            .from('products')
            .select('*')
            .eq('is_active', true)
            .eq('is_trending', true)
            .limit(section.max_products)
            .order('name');

          if (error) throw error;
          productsData = data;
        } else {
          const categorySlug = section.categories?.slug;
          if (!categorySlug) continue;

          const { data, error } = await supabase
            .from('products')
            .select('*')
            .eq('is_active', true)
            .eq('category', categorySlug)
            .limit(section.max_products)
            .order('name');

          if (error) throw error;
          productsData = data;
        }

        const productsWithCounts = (productsData || []).map(product => ({
          ...product,
          offers: offerCounts[product.id] || 0
        }));

        sections.push({
          section,
          products: productsWithCounts
        });
      }

      setCategorySections(sections);
    } catch (error) {
      console.error('Error fetching data:', error);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-gray-50">
      <Header />
      <SearchBar activeCategory={activeCategory} onCategoryChange={setActiveCategory} />

      {noticeBar.enabled && noticeBar.text && (
        <div
          className="w-full py-3 px-4"
          style={{ backgroundColor: noticeBar.bgColor }}
        >
          <div className="max-w-7xl mx-auto">
            {noticeBar.link ? (
              <a
                href={noticeBar.link}
                target="_blank"
                rel="noopener noreferrer"
                className="flex items-center justify-center gap-3 hover:opacity-90 transition-opacity"
              >
                {noticeBar.imageUrl && (
                  <img
                    src={noticeBar.imageUrl}
                    alt="Notice"
                    className="h-8 w-auto object-contain"
                  />
                )}
                <span
                  className="text-center font-medium text-sm sm:text-base"
                  style={{ color: noticeBar.textColor }}
                >
                  {noticeBar.text}
                </span>
              </a>
            ) : (
              <div className="flex items-center justify-center gap-3">
                {noticeBar.imageUrl && (
                  <img
                    src={noticeBar.imageUrl}
                    alt="Notice"
                    className="h-8 w-auto object-contain"
                  />
                )}
                <span
                  className="text-center font-medium text-sm sm:text-base"
                  style={{ color: noticeBar.textColor }}
                >
                  {noticeBar.text}
                </span>
              </div>
            )}
          </div>
        </div>
      )}

      {bannerUrl && (
        <div className="w-full mb-2 sm:mb-3 lg:mb-4">
          {mobileBannerUrl ? (
            <>
              <img
                src={mobileBannerUrl}
                alt="Homepage Banner"
                className="w-full h-auto object-cover md:hidden"
              />
              <img
                src={bannerUrl}
                alt="Homepage Banner"
                className="w-full h-auto object-cover hidden md:block"
              />
            </>
          ) : (
            <img
              src={bannerUrl}
              alt="Homepage Banner"
              className="w-full h-auto object-cover"
            />
          )}
        </div>
      )}

      <main className="max-w-7xl mx-auto px-2 sm:px-4 lg:px-8 py-2 sm:py-4 lg:py-6">
        {loading ? (
          <div className="text-gray-900 text-center py-8 sm:py-12">Loading products...</div>
        ) : (
          <>
            {categorySections.map((categorySection, index) => (
              <section key={categorySection.section.id} className={index < categorySections.length - 1 ? 'mb-8 sm:mb-12 lg:mb-16' : ''}>
                {categorySection.section.show_title && categorySection.section.title && (
                  <div className="mb-6 sm:mb-8 lg:mb-10">
                    <div className="bg-white border border-gray-200 rounded-lg px-6 py-4 shadow-sm">
                      <h2 className="text-gray-900 text-lg sm:text-xl lg:text-2xl font-bold text-center">{categorySection.section.title}</h2>
                    </div>
                  </div>
                )}
                <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 gap-2 sm:gap-3 lg:gap-4">
                  {categorySection.products.map((product) => (
                    <BrandCard
                      key={product.id}
                      id={product.id}
                      slug={product.slug}
                      name={product.name}
                      offers={product.offers}
                      image={product.image_url}
                    />
                  ))}
                </div>
                {categorySection.products.length === 0 && (
                  <p className="text-gray-600 text-center py-8">No products available in this section</p>
                )}
              </section>
            ))}

            {categorySections.length === 0 && (
              <p className="text-gray-600 text-center py-8">No products available</p>
            )}
          </>
        )}
      </main>
      <Footer />
    </div>
  );
}
